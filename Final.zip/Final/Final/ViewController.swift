//
//  ViewController.swift
//  Final
//
//  Created by X D on 12/10/22.
//

import UIKit
import PromiseKit
import Alamofire
import SwiftyJSON

class ViewController: UIViewController, UITableViewDelegate,UITableViewDataSource,SendStockDelegate {
    @IBOutlet weak var tblView: UITableView!

    @IBOutlet weak var symbol: UILabel!
    @IBOutlet weak var company: UILabel!
    @IBOutlet weak var Price: UILabel!
    
    var stocks : [StockModel] = [StockModel]()
    var detail = [""]
    var info = [""]
    var indexSelected = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        getAllData()
        // Do any additional setup after loading the view.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(info.count)
        return info.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = Bundle.main.loadNibNamed("StockTableViewCell", owner: self, options: nil)?.first as! StockTableViewCell
        
        cell.lblSymbol?.text = info[indexPath.row];
        cell.lblInfo?.text = detail[indexPath.row];
        cell.symbol = info[indexPath.row];
        cell.sendStockDelegate = self

        return cell;
    }
    
    

     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            indexSelected = indexPath.row
            performSegue(withIdentifier: "segueDetails", sender: self)
    }
    
    func getAllData(){
        let url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/allstocks"
        
            
            AF.request(url).responseJSON { response in
                
                if response.error != nil {
                    print(response.error!)
                    return
                }
                
                let allData = JSON(response.data as Any)
//                let stockModel = StockModel("", 0.0, "")
                
                //get data here
//                let StockModel = JSON(response.data!).arrayValue
                
//                guard let JSON = StockModel.first else {return seal.fulfill(stockModel)}
                
                print(allData)
                
                for data in allData {
//                    print(data)
                    let dataJSON = JSON(data.1)
                    print(dataJSON)
                    
                    let name = dataJSON["CompanyName"].stringValue
                    let symbol = dataJSON["Symbol"].stringValue
                    let price = dataJSON["Price"].doubleValue

                    self.info.append( symbol )
                    self.detail.append( name +  " " + String(price) )
                }
//                stockModel.symbol  = stockJSON["Symbol"].stringValue
//                stockModel.price = stockJSON["Price"].doubleValue
//                stockModel.des = stockJSON["CompanyName"].stringValue
//
//                print(self.stocks)
//                seal.fulfill(stockModel)
                print(self.info)
                self.tblView.reloadData()

            }// end of response
        
    }//end of function
    
    func sendStockData(_ stockModel: StockModel) {
        print("de")
        company.text = "Company: \(stockModel.des)";
        symbol.text = stockModel.symbol
        Price.text = "$ \(stockModel.price)"
    }
}

