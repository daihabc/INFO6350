//
//  APIURLFile.swift
//  Final
//
//  Created by X D on 12/10/22.
//

import Foundation

let companyQuoteURL = "https://financialmodelingprep.com/api/v3/quote/"
