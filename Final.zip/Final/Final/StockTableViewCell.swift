//
//  StockTableViewCell.swift
//  Final
//
//  Created by X D on 12/10/22.
//

import UIKit
import Alamofire
import SwiftyJSON
import PromiseKit
import Foundation



class StockTableViewCell: UITableViewCell {

    var symbol = ""
    
    var sendStockDelegate: SendStockDelegate?

    @IBOutlet weak var lblSymbol: UILabel!
    @IBOutlet weak var lblInfo: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func getCompanyData(_ url : String) -> Promise<StockModel>{
        
        return Promise<StockModel> { seal -> Void in
            
            AF.request(url).responseJSON { response in
                
                if response.error != nil {
                    print("error")
                    seal.reject(response.error!)
                }
                
                print("tenter")
                let stockModel = StockModel("", 0.0, "")
                
                //get data here
                let StockModel = JSON(response.data!).arrayValue
                
                guard let stockJSON = StockModel.first else {return seal.fulfill(stockModel)}
                
                stockModel.symbol  = stockJSON["Symbol"].stringValue
                stockModel.price = stockJSON["Price"].doubleValue
                stockModel.des = stockJSON["CompanyName"].stringValue
                
                print("test")
                print(stockModel.symbol)
                seal.fulfill(stockModel)
                
            }// end of response
        }// end is return Promise
    }//end of function
    
    
    @IBAction func getInfo(_ sender: Any) {
        var url = "https://us-central1-whatsapp-analytics-2de0e.cloudfunctions.net/app/getstock?symbol="
        url += symbol

        
        getCompanyData(url)
            .done{ stockModel in
                self.sendStockDelegate?.sendStockData(stockModel)
            }.catch{ error in
                print(error.localizedDescription)
            }
    
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
