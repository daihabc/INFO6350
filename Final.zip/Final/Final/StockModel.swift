//
//  StockModel.swift
//  Final
//
//  Created by X D on 12/10/22.
//

import Foundation

class StockModel {
    
    var symbol = ""
    var price = 0.0
    var des = " "
    
    init(_ symbol: String, _ price: Double, _ des: String){
        self.price = price
        self.symbol = symbol
        self.des = des
//        self.price = price
//        self.dayHigh = dayHigh
//        self.dayLow = dayLow
    }
}
