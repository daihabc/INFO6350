//
//  SendStockDelegate.swift
//  Final
//
//  Created by X D on 12/10/22.
//

import Foundation

protocol SendStockDelegate {
    func sendStockData(_ stockModel : StockModel)
}
