//
//  ViewController.swift
//  WeatherForecast
//
//  Created by X D on 11/19/22.
//

import UIKit
import CoreLocation
import Alamofire
import SwiftSpinner
import SwiftyJSON

class ViewController: UIViewController, CLLocationManagerDelegate, UITableViewDelegate, UITableViewDataSource  {
    

    @IBOutlet weak var tblView: UITableView!
    @IBOutlet weak var txtLocation: UITextField!
    
    let locationManager = CLLocationManager()
    var addressText = ""
    var latlng = ""
    var info = [""]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        
        let lat = location.coordinate.latitude
        let lng = location.coordinate.longitude
        
        print(lat)
        print(lng)
        
        self.latlng = String(lat) + "," + String(lng)
        print(self.latlng)
        
    }

    @IBAction func getLocation(_ sender: Any) {
        let locationStr =  self.latlng

             var url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations="

             url += locationStr

             url += "&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key=PROFAPIKEY"

                     AF.request(url).responseJSON { responseData in

                         if responseData.error != nil {
                             print(responseData.error!)
                             return
                         }

                         let weatherData = JSON(responseData.data as Any)

                        // guard let stock = JSON(responseData.data!).array else { return }

                         let forecastValues =  weatherData["locations"][ self.latlng]["values"]
                         

                         print(forecastValues.count)

                         for forecast in forecastValues {

                             let forecastJSON = JSON(forecast.1)

                             let temp = forecastJSON["temp"].floatValue
                             let condition = forecastJSON["conditions"].stringValue
                             
                             self.info.append(String(temp) + " " + condition)

                            print(forecast)

                         }
                         self.tblView.reloadData()

                     }
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }
    
    
    @IBAction func checkWeather(_ sender: UIButton) {
        let locationStr = txtLocation.text!

        var url = "https://weather.visualcrossing.com/VisualCrossingWebServices/rest/services/weatherdata/forecast?locations="

        url += locationStr

        url += "&aggregateHours=24&unitGroup=us&shortColumnNames=false&contentType=json&key=AYQR6QM5KHFYVPH9M4EXXJUCC"

                AF.request(url).responseJSON { responseData in

                    if responseData.error != nil {
                        print(responseData.error!)
                        return
                    }

                    let weatherData = JSON(responseData.data as Any)

                   // guard let stock = JSON(responseData.data!).array else { return }

                    let forecastValues =  weatherData["locations"][self.txtLocation.text!]["values"]
                    

                    print(forecastValues.count)

                    for forecast in forecastValues {

                        let forecastJSON = JSON(forecast.1)

                        let temp = forecastJSON["temp"].floatValue
                        let condition = forecastJSON["conditions"].stringValue
                        
                        self.info.append(String(temp) + " " + condition)

                       print(forecast)

                    }
                    self.tblView.reloadData()

                }
    }
    
    //tableview

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("tbtest")
        print(info)

        return info.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath);
        let cell = Bundle.main.loadNibNamed("TableViewCell", owner: self)?.first as! TableViewCell

        cell.txtLabel?.text = info[indexPath.row]
        return cell;
    }

}

