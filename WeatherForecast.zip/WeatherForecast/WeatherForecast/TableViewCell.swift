//
//  TableViewCell.swift
//  WeatherForecast
//
//  Created by X D on 11/19/22.
//

import UIKit

class TableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var txtLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

//    override func setSelected(_ selected: Bool, animated: Bool) {
//        super.setSelected(selected, animated: animated)
//
//        // Configure the view for the selected state
//    }
//    
    
}
